<?php
/* 
 * Stock by Attributes 1.5.4
*/
define('TABLE_PRODUCTS_WITH_ATTRIBUTES_STOCK', DB_PREFIX . 'products_with_attributes_stock');
define('TABLE_ORDERS_PRODUCTS_ATTRIBUTES_STOCK', DB_PREFIX . 'orders_products_attributes_stock');
define('TABLE_PRODUCTS_WITH_ATTRIBUTES_STOCK_ATTRIBUTES_NON_STOCK', DB_PREFIX . 'products_with_attributes_stock_attributes_non_stock');

