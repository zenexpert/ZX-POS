<?php
if (!defined('TABLE_PRODUCTS_STOCK')) define('TABLE_PRODUCTS_STOCK', DB_PREFIX. 'products_with_attributes_stock');
