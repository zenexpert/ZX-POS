<?php

/*
 * Updated  15-11-14 mc12345678
 *
 *
 */
define('TEXT_OUT_OF_STOCK', 'Out of stock');
define('TEXT_OUT_OF_STOCK_LEFT', 'Out of stock - ');
define('TEXT_OUT_OF_STOCK_RIGHT', ' - Out of stock');
define('TEXT_ON_BACKORDER', 'On backorder');
define('TEXT_ON_BACKORDER_LEFT', 'On backorder - ');
define('TEXT_ON_BACKORDER_RIGHT', ' - On backorder');
define('TEXT_OUT_OF_STOCK_MESSAGE', 'The combination of options you have selected is currently out of stock.  Please select another combination.');
define('TEXT_SELECT_OPTIONS', 'Please select the applicable option(s) before adding to the cart.');
define('TEXT_SEQUENCED_FIRST', 'First select ');
define('TEXT_SEQUENCED_NEXT', 'Next select ');
define('TEXT_JAVA_ALL_SELECT_OUT', 'All selections of the attributes below this one are Out of Stock. Please select a different option.');
define('TEXT_JAVA_ONE_SELECT_OUT', 'Your choice is out of stock.');
