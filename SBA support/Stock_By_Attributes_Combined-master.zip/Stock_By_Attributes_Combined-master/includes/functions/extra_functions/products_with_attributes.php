<?php
/**
 * @package includes/functions/extra_functions
 * products_with_attributes.php
 *
 * @package functions/extra_functions
 * @copyright Copyright 2003-2019 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id:  $
 * 
 * Stock by Attributes 1.5.4+ :  19-01-04 mc12345678
 */

//The code formally in this file has been captured elsewhere in this
//  plugin making this file no longer necessary.  It can be deleted.
