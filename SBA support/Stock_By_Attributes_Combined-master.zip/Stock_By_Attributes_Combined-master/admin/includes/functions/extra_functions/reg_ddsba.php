<?php
/**
 * Simple install script for Dynamic Dropdowns For SBA
 * All this does is add an admin menu option for DD-SBA configuration choices
 
 This has been moved to the applicable language folder:
 admin/includes/languages/YOUR_LANGUAGE/extra_definitions/reg_ddsba.php
 This file can be deleted but is here as part of the rebuild/upgrade.

*/