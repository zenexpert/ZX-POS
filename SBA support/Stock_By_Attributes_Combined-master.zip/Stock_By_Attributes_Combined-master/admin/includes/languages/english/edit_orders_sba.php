<?php 
  
  define('WARNING_ORDER_UPDATE_VARIANT_DOES_NOT_EXIST_SBA', 'Product %3$s in the list below, named \'%1$s\', with a quantity of %4$.' . QUANTITY_DECIMALS . 'f did not exist.  Attribute(s) selected: %2$s Its attribute(s) were not updated.');
  define('WARNING_ORDER_ADD_VARIANT_DOES_NOT_EXIST_SBA', 'The product named \'%1$s\' did not exist with attribute(s): %2$s Please select a different variant of attribute options.');
  define('WARNING_ORDER_ADD_VARIANT_OUT_OF_STOCK_SBA', 'The product named \'%1$s\' was out-of-stock with attribute(s): %2$s It was not added. Quantity available was %3$.' . QUANTITY_DECIMALS . 'f.');
