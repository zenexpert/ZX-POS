<?php
/* Products with attributes stock
 * Stock by Attributes 1.5.3.1
 */
define('BOX_CATALOG_PRODUCTS_WITH_ATTRIBUTES_STOCK', 'Stock de Produits avec Attributs (aka SBA)');
define('BOX_CONFIGURATION_PRODUCTS_WITH_ATTRIBUTES_STOCK_SETUP', 'Stock de Produits avec Attributs (aka SBA) Setup');
define('BOX_CONFIGURATION_PRODUCTS_WITH_ATTRIBUTES_STOCK_AJAX', 'Stock de Produits avec Attributs Ajax');
define('IMAGE_OPTION_SBA', 'Link to SBA');
define('TEXT_SBA_EDIT', 'SBA THIS PRODUCT');
define('TEXT_NO_SBA_EDIT', 'Product Not SBA Tracked');