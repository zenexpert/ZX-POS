<?php
/* Products with attributes stock
 * Stock by Attributes 1.5.3.1
 */
define('BOX_CATALOG_PRODUCTS_WITH_ATTRIBUTES_STOCK', 'Products with Attributes Stock (aka SBA) Dutch');
define('BOX_CONFIGURATION_PRODUCTS_WITH_ATTRIBUTES_STOCK_SETUP', 'Products with Attributes Stock (aka SBA) Setup Dutch');
define('BOX_CONFIGURATION_PRODUCTS_WITH_ATTRIBUTES_STOCK_AJAX', 'Products with Attributes Stock Ajax Dutch');
define('IMAGE_OPTION_SBA', 'Link to SBA');
define('TEXT_SBA_EDIT', 'SBA THIS PRODUCT');
define('TEXT_NO_SBA_EDIT', 'Product Not SBA Tracked');