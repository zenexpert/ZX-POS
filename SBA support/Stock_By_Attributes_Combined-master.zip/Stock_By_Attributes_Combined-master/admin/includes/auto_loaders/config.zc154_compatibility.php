<?php
// -----
// Load the Zen Cart v1.5.4 compatibility module.
// Copyright (c) 2014 Vinos de Frutas Tropicales
//
$autoLoadConfig[65][]  = array ('autoType' => 'init_script',
                                'loadFile' => 'init_zc154_compatibility.php');