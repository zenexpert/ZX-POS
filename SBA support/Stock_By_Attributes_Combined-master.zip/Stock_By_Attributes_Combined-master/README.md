Stock_By_Attributes_Combined
========================

Stock by Attributes (SBA) for Zen Cart 1.5.0, 1.5.1, 1.5.3, 1.5.4, 1.5.5 (all sub-versions), and Zen Cart 1.5.6

This SBA Modification will only work with Zen Cart 1.5.0, 1.5.1, Zen Cart 1.5.3, Zen Cart 1.5.4, Zen Cart 1.5.5, and Zen Cart 1.5.6.
This is due to the new functionality and code changes that have been added to support the newer version of Zen Cart.

While many ZC forum threads exist on the basic software of Stock By Attributes.  The thread that has been chosen or persisted
for this plugin is: [Stock by Attribute v4.0 addon for v1.3.5-1.3.9](https://www.zen-cart.com/showthread.php?47180-Stock-by-Attribute-v4-0-addon-for-v1-3-5-1-3-9).  
Please seek assistance there.
